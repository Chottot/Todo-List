public class EmailSenderService {

    public static void sendEmail(){

    }
}
